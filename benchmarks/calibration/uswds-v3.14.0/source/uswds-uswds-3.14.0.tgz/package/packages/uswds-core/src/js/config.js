module.exports = {
  prefix: "usa",
};
